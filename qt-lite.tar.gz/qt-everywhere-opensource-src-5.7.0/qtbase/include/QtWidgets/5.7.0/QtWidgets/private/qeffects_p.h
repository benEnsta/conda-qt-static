#include "../../../../../src/widgets/widgets/qeffects_p.h"
