#include "../../src/widgets/widgets/qslider.h"
