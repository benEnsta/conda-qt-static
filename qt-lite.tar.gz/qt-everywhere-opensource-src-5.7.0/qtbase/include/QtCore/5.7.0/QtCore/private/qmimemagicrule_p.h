#include "../../../../../src/corelib/mimetypes/qmimemagicrule_p.h"
