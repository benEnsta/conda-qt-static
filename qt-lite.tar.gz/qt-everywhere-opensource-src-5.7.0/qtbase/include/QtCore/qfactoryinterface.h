#include "../../src/corelib/plugin/qfactoryinterface.h"
